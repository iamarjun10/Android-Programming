package com.example.camera2;

import android.content.ClipData;
import android.graphics.Bitmap;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class SharedViewModel extends ViewModel {

    private final MutableLiveData<Bitmap> selected = new MutableLiveData<Bitmap>();

    public void select(Bitmap item) {
        selected.setValue(item);
    }

    public LiveData<Bitmap> getSelected() {
        return selected;
    }

}
