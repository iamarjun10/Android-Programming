package com.example.api_prac;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Api_Interface {

     String BASE_URL="https://simplifiedcoding.net/demos/";

    @GET("marvel")
    Call<ArrayList<Api>> getHeroes();

}
