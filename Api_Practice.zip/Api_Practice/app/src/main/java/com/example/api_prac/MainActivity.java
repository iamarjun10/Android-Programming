package com.example.api_prac;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.annotation.Retention;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView textView = (TextView) findViewById(R.id.textview);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api_Interface.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Api_Interface api_interface = retrofit.create(Api_Interface.class);

        Call<ArrayList<Api>> call = api_interface.getHeroes();

        call.enqueue(new Callback<ArrayList<Api>>() {
            @Override
            public void onResponse(Call<ArrayList<Api>> call, Response<ArrayList<Api>> response) {
                ArrayList<Api> list = response.body();
                textView.setText(list.get(0).getBio());

            }

            @Override
            public void onFailure(Call<ArrayList<Api>> call, Throwable t) {
                Toast.makeText(MainActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }
}